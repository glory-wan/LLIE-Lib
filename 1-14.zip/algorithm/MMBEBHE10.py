import numpy as np
import cv2
from matplotlib import pyplot as plt


def MMBEBHE(image):
    # 计算图像直方图
    hist, bins = np.histogram(image.flatten(), 256, [0, 256])

    # 计算累计直方图
    cdf = hist.cumsum()
    cdf_normalized = cdf * hist.max() / cdf.max()

    # 计算图像的平均亮度
    mean_brightness = np.mean(image)

    # 初始化变量
    min_mean_brightness_error = float('inf')
    optimal_threshold = -1

    # 遍历所有可能的阈值
    for t in range(256):
        # 将图像分为两部分
        w0 = cdf[t]  # 前景像素点的数量
        w1 = cdf[-1] - cdf[t]  # 背景像素点的数量

        if w0 == 0 or w1 == 0:
            continue

        mean0 = np.sum(hist[:t] * np.arange(t)) / w0  # 前景的平均亮度
        mean1 = np.sum(hist[t:] * np.arange(t, 256)) / w1  # 背景的平均亮度

        # 计算当前阈值的平均亮度误差
        mean_brightness_error = w0 * (mean0 - mean_brightness) ** 2 + w1 * (mean1 - mean_brightness) ** 2

        # 更新最小平均亮度误差和最佳阈值
        if mean_brightness_error < min_mean_brightness_error:
            min_mean_brightness_error = mean_brightness_error
            optimal_threshold = t

    # 使用最佳阈值对图像进行双直方图均衡化
    output_image = np.copy(image)
    foreground_pixels = image <= optimal_threshold
    background_pixels = image > optimal_threshold

    # 将二维数组展平为一维数组，然后应用直方图均衡化
    flat_foreground = image[foreground_pixels].flatten()
    flat_background = image[background_pixels].flatten()

    output_image[foreground_pixels] = cv2.equalizeHist(flat_foreground).reshape(image[foreground_pixels].shape)
    output_image[background_pixels] = cv2.equalizeHist(flat_background).reshape(image[background_pixels].shape)

    return output_image


# 读取图像
image = cv2.imread('input.jpg', 0)  # 以灰度模式读取图像

# 应用MMBEBHE算法
enhanced_image = MMBEBHE(image)

# 显示结果
plt.figure(figsize=(12, 6))
plt.subplot(121), plt.imshow(image, cmap='gray'), plt.title('Original Image')
plt.subplot(122), plt.imshow(enhanced_image, cmap='gray'), plt.title('Enhanced Image')
plt.show()
