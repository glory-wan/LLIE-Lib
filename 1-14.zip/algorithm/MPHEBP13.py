import cv2
import numpy as np
from scipy.stats import norm


def mphebp(image, prior_mean, prior_variance, variance_prior_alpha, variance_prior_beta):
    # 将图像转换为灰度图像
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 将灰度图像转换为一维数组
    data = gray_image.flatten()

    # 计算图像的均值和方差
    sample_mean = np.mean(data)
    sample_variance = np.var(data)

    # 计算后验分布的参数
    posterior_variance = 1 / (1 / prior_variance + len(data) / sample_variance)
    posterior_mean = (prior_mean / prior_variance + np.sum(data) / sample_variance) * posterior_variance

    # 计算方差的后验分布的参数
    posterior_variance_alpha = variance_prior_alpha + len(data) / 2
    posterior_variance_beta = variance_prior_beta + 0.5 * np.sum((data - sample_mean) ** 2) + \
                              (len(data) * prior_variance) / (len(data) + prior_variance) * (
                                          (sample_mean - prior_mean) ** 2) / 2

    # 使用后验均值和方差进行直方图均衡化
    equalized_image = cv2.equalizeHist(gray_image)

    return equalized_image


# 读取图像
image = cv2.imread('input.jpg')

# 设置先验分布的参数
prior_mean = 128
prior_variance = 100
variance_prior_alpha = 1
variance_prior_beta = 1

# 应用MPHEBP进行图像增强
enhanced_image = mphebp(image, prior_mean, prior_variance, variance_prior_alpha, variance_prior_beta)

# 显示原始图像和增强后的图像
cv2.imshow('Original Image', image)
cv2.imshow('Enhanced Image', enhanced_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
