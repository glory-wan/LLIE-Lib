import cv2
# 现在执行你的代码


def enhance_contrast(image_path):
    # 读取图像
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # 创建CLAHE对象
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))

    # 对图像进行CLAHE处理
    enhanced_image = clahe.apply(image)

    # 显示增强后的图像
    cv2.imshow("Enhanced Image", enhanced_image)

    # 等待用户按下任意键
    cv2.waitKey(0)

    # 关闭所有OpenCV窗口
    cv2.destroyAllWindows()

    print("图像对比度增强完成！")


# 调用函数进行图像对比度增强
enhance_contrast("input.jpg")
