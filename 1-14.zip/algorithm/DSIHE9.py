import numpy as np
import cv2
import matplotlib.pyplot as plt

# 计算图像的直方图
def compute_histogram(image):
    histogram = np.zeros(256, dtype=int)
    for pixel in image.flatten():
        histogram[pixel] += 1
    return histogram

# 计算累积分布函数（CDF）
def compute_cdf(histogram):
    cdf = histogram.cumsum()
    cdf_normalized = cdf * 255 / cdf[-1]  # 归一化到[0, 255]
    return cdf_normalized

# 使用CDF将图像中的每个像素值映射到新的值
def map_histogram(image, cdf):
    equalized_image = np.interp(image.flatten(), range(0, 256), cdf)
    return equalized_image.reshape(image.shape)

# 应用DSIHE算法
def DSIHE(image, iterations=10):
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # 将图像转换为灰度图像
    for _ in range(iterations):
        histogram = compute_histogram(image)
        cdf = compute_cdf(histogram)
        image = map_histogram(image, cdf).astype(np.uint8)
    return image

# 加载示例图像
image_path = 'input.jpg'
image = cv2.imread(image_path)

# 检查图像是否成功加载
if image is None:
    raise FileNotFoundError(f"无法加载图像文件：{image_path}")

# 应用DSIHE
enhanced_image = DSIHE(image, iterations=10)

# 显示结果
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.title('原始图像')
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.subplot(1, 2, 2)
plt.title('DSIHE增强图像')
plt.imshow(enhanced_image, cmap='gray')
plt.show()
