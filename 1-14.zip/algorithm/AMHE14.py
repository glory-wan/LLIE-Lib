import cv2
import numpy as np


def amhe(image, window_size, clip_limit):
    # 将图像转换为灰度图像
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 获取图像尺寸
    height, width = gray_image.shape

    # 对每个像素应用AMHE算法
    for y in range(height):
        for x in range(width):
            # 计算窗口的边界
            x_start = max(0, x - window_size // 2)
            x_end = min(width - 1, x + window_size // 2)
            y_start = max(0, y - window_size // 2)
            y_end = min(height - 1, y + window_size // 2)

            # 获取窗口内的像素值
            window_pixels = gray_image[y_start:y_end + 1, x_start:x_end + 1]

            # 计算直方图
            hist, _ = np.histogram(window_pixels, bins=256, range=(0, 255))

            # 计算累积直方图
            cum_hist = np.cumsum(hist)

            # 计算最大值和最小值
            min_val = cum_hist.min()
            max_val = cum_hist.max()

            # 对直方图进行调整
            adjusted_hist = (cum_hist - min_val) * (clip_limit / (max_val - min_val))
            adjusted_hist = np.clip(adjusted_hist, 0, 255)
            adjusted_hist = adjusted_hist / adjusted_hist.max() * 255

            # 计算输出像素值
            output_pixel = adjusted_hist[gray_image[y, x]]

            # 更新输出图像
            gray_image[y, x] = output_pixel

    return gray_image


# 读取图像
image = cv2.imread('input.jpg')

# 设置窗口大小和clip_limit
window_size = 15
clip_limit = 2.0

# 应用AMHE进行图像增强
enhanced_image = amhe(image, window_size, clip_limit)

# 显示原始图像和增强后的图像
cv2.imshow('Original Image', image)
cv2.imshow('Enhanced Image', enhanced_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
