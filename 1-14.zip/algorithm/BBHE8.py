import cv2
import numpy as np
import matplotlib.pyplot as plt


def bbhe(image):
    # 将图像转换为灰度图像
    if len(image.shape) == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 计算图像的平均亮度
    mean_brightness = np.mean(image)

    # 将图像分为两个子图像
    lower_part = image[image <= mean_brightness]
    upper_part = image[image > mean_brightness]

    # 计算每个子图像的直方图
    lower_hist, _ = np.histogram(lower_part, bins=256, range=(0, 256))
    upper_hist, _ = np.histogram(upper_part, bins=256, range=(0, 256))

    # 计算累积直方图
    lower_cdf = np.cumsum(lower_hist)
    upper_cdf = np.cumsum(upper_hist)

    # 归一化累积直方图
    lower_cdf = (lower_cdf - lower_cdf.min()) * 255 / (lower_cdf.max() - lower_cdf.min())
    upper_cdf = (upper_cdf - upper_cdf.min()) * 255 / (upper_cdf.max() - upper_cdf.min())

    # 创建映射表
    lower_map = np.zeros(256, dtype=np.uint8)
    upper_map = np.zeros(256, dtype=np.uint8)

    lower_map[:int(mean_brightness) + 1] = lower_cdf[:int(mean_brightness) + 1]
    upper_map[int(mean_brightness) + 1:] = upper_cdf[int(mean_brightness) + 1:]

    # 应用映射表
    equalized_image = image.copy()
    equalized_image[image <= mean_brightness] = lower_map[image[image <= mean_brightness]]
    equalized_image[image > mean_brightness] = upper_map[image[image > mean_brightness]]

    return equalized_image


# 读取图像
image = cv2.imread('input.jpg', cv2.IMREAD_COLOR)

# 检查图像是否读取成功
if image is None:
    print("Error: Could not open or find the image.")
    exit()

# 应用BBHE算法
equalized_image = bbhe(image)

# 显示原图和处理后的图像
plt.figure(figsize=(12, 6))
plt.subplot(1, 2, 1)
plt.title('Original Image')
plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
plt.axis('off')  # 关闭坐标轴

plt.subplot(1, 2, 2)
plt.title('BBHE Image')
plt.imshow(equalized_image, cmap='gray')
plt.axis('off')  # 关闭坐标轴

plt.show()
