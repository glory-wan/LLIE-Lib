import cv2
import numpy as np

def recursive_mean_separate_histogram_equalization(image, num_levels=4, alpha=0.5):
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image.copy()

    output = np.zeros_like(gray, dtype=np.float32)
    equalized = cv2.equalizeHist(gray)
    scaled = alpha * equalized / 255

    for _ in range(num_levels):
        blurred = cv2.GaussianBlur(scaled, (5, 5), 0)
        detail = scaled - blurred
        scaled = detail + alpha * cv2.equalizeHist((blurred * 255).astype(np.uint8)) / 255

    output = (scaled * 255).astype(np.uint8)

    return output

# Load the input image
input_image = cv2.imread('input.jpg')

# Enhance the image
enhanced_image = recursive_mean_separate_histogram_equalization(input_image)

# Display the original and enhanced images
cv2.imshow('Original Image', input_image)
cv2.imshow('Enhanced Image', enhanced_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
