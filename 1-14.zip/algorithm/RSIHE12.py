import cv2
import numpy as np

def RSIHE(image, num_levels=4, clip_limit=3.0, tile_grid_size=(8, 8)):
    if len(image.shape) == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image.copy()

    def adaptive_histogram_equalization(img):
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
        return clahe.apply(img)

    def recursive_mean_separation(img, levels):
        if levels == 0:
            return img

        mean_value = np.mean(img)
        lower_mask = img <= mean_value
        upper_mask = img > mean_value

        lower_part = img.copy()
        lower_part[~lower_mask] = 0
        upper_part = img.copy()
        upper_part[~upper_mask] = 0

        if np.any(lower_mask):
            lower_equalized = adaptive_histogram_equalization(lower_part)
            img[lower_mask] = lower_equalized[lower_mask]
        if np.any(upper_mask):
            upper_equalized = adaptive_histogram_equalization(upper_part)
            img[upper_mask] = upper_equalized[upper_mask]

        return recursive_mean_separation(img, levels - 1)

    enhanced_image = recursive_mean_separation(gray, num_levels)
    return enhanced_image

# 加载输入图像
input_image = cv2.imread('input.jpg')

# 使用RSIHE增强图像
enhanced_image = RSIHE(input_image, num_levels=6, clip_limit=3.5)

# 显示原始和增强后的图像
cv2.imshow('Original Image', input_image)
cv2.imshow('Enhanced Image', enhanced_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
